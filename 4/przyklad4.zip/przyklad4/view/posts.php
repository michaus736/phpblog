<section>
  <nav>
  <table><tr>
  <td style="width: 33.3%;"></td>
  <td  style="width: 33.3%;">
    <a href="<?=$this->baseurl?>?cmd=topics">Lista tematów</a>
  </td>
  <td  style="width: 33.3%;"></td>
  </tr></table>
  </nav>

  <article  class="topic">
    <header>Temat dyskusji: <b><?=htmlentities($topic['topic'])?></b></header>
    <div><?=nl2br(htmlentities($topic['topic_body']))?></div>
    <footer>
    ID: <?=$topic['topicid']?>, Autor: <?=htmlentities($users[$topic['userid']]['username'])?>, Data: <?=$topic['date']?>
    </footer>
  </article>
<?php if( !$posts ){ ?>
  <p>To forum nie zawiera jeszcze żadnych głosów w dyskusji!</p>
<?php }else{ ?>
<?php foreach($posts as $k=>$v){ ?>
  <article>
  <div><?=nl2br(htmlentities($v['post']))?></div>
  <footer>
  <?php if( $this->u['userlevel']==10 or $this->u['userid']==$v['userid']){ ?>
  <nav>
  <a href="?id=<?=$v['postid']?>&cmd=edit">EDYTUJ</a>  
  <a class="danger" href="?&id=<?=$v['postid']?>&cmd=delete">KASUJ</a>
  </nav> 
  <?php } ?>
  ID: <?=$v['postid']?>, Autor: <?=htmlentities($users[$v['userid']]['username'])?>, Utworzono dnia: <?=$v['date']?></footer>
  </article>
<?php } } ?>

  <form action="<?=$this->baseurl?>" method="post" enctype="multipart/form-data">
     <a name="post_form" ></a>
     <header><h2><?php if($post){ ?>Edytuj wypowiedź<?php }else{ ?>Dodaj nowa wypowiedź do dyskusji<?php } ?></h2></header>  
     <textarea name="post" autofocus cols="80" rows="10" placeholder="Wpisz tu swoją wypowiedź." ><?=($post)?$post["post"]:'';?></textarea><br />
     <input type="hidden" name="postid" value="<?=($post)?$post["postid"]:"";?>" />
     <button type="submit" >Zapisz</button>
  </form>

</section>
