
<footer>
Ostatni wpis na formu powstal dnia: <?=$last_post?>
</footer>
</body>
</html>